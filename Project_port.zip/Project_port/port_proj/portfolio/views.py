from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Avg, Count
from .models import Project, Rating
from .forms import RatingForm


def project_list(request):
    projects = Project.objects.annotate(
        avg_score=Avg('ratings__score'),
        num_ratings=Count('ratings')
    ).order_by('-avg_score')
    return render(request, 'portfolio/project_list.html', {'projects': projects})



def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    form = RatingForm()
    return render(request, 'portfolio/project_detail.html', {
        'project': project,
        'form': form,
    })

def rate_project(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if request.method == 'POST':
        form = RatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.project = project
            rating.save()
    return redirect('portfolio:detail', pk=pk)
