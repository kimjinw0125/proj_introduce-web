from django.db import models

class Project(models.Model):
    title       = models.CharField(max_length=100)
    description = models.TextField()
    image       = models.ImageField(upload_to='projects/')
    repo_url    = models.URLField(blank=True, null=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    def average_score(self):
        return self.ratings.aggregate(models.Avg('score'))['score__avg'] or 0

    def num_ratings(self):
        return self.ratings.count()

    def __str__(self):
        return self.title

class Rating(models.Model):
    project    = models.ForeignKey(Project, related_name='ratings', on_delete=models.CASCADE)
    score      = models.PositiveSmallIntegerField(choices=[(i,i) for i in range(1,6)])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.project.title} — {self.score}"
