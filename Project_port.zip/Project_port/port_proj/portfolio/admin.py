from django.contrib import admin
from django.db.models import Avg, Count
from .models import Project, Rating

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('rank', 'title', 'average_score', 'num_ratings')

    def get_queryset(self, request):
        qs = super().get_queryset(request).annotate(
            avg_score=Avg('ratings__score'),
            num_ratings=Count('ratings'),
        ).order_by('-avg_score')      
        self._rank_map = {proj.pk: idx for idx, proj in enumerate(qs, start=1)}
        return qs

    def average_score(self, obj):
        return round(obj.avg_score or 0, 1)
    average_score.admin_order_field = 'avg_score'
    average_score.short_description = '평균점수'

    def num_ratings(self, obj):
        return obj.num_ratings
    num_ratings.admin_order_field = 'num_ratings'
    num_ratings.short_description = '투표수'

    def rank(self, obj):
        return self._rank_map.get(obj.pk, '-')
    rank.admin_order_field = 'avg_score'
    rank.short_description = '순위'

@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ('project', 'score', 'created_at')
